
<?php require_once('constant.inc.php');
require('config/user.class.php'); 
$user = new userService();
?>


